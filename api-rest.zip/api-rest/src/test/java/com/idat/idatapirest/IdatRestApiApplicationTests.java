package com.idat.idatapirest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IdatRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
