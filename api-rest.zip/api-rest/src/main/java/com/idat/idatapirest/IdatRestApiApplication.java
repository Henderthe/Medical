package com.idat.idatapirest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IdatRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(IdatRestApiApplication.class, args);
	}

}
