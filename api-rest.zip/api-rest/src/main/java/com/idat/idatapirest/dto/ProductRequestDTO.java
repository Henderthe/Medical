package com.idat.idatapirest.dto;

public class ProductRequestDTO {

        private Integer idRequest;
        private String nombreProducto;
        private String descripcionProducto;
        private Double precioProducto;
        private Integer stockProducto;

        public Integer getIdRequest() {
            return idRequest;
        }
        public void setIdRequest(Integer idRequest) {
            this.idRequest = idRequest;
        }
        public String getNombreProducto() {
            return nombreProducto;
        }
        public void setNombreProducto(String nombreProducto) {
            this.nombreProducto = nombreProducto;
        }
        public String getDescripcionProducto() {
            return descripcionProducto;
        }
        public void setDescripcionProducto(String descripcionProducto) {
            this.descripcionProducto = descripcionProducto;
        }
        public Double getPrecioProducto() {
            return precioProducto;
        }
        public void setPrecioProducto(Double precioProducto) {
            this.precioProducto = precioProducto;
        }
        public Integer getStockProducto() {
            return stockProducto;
        }
        public void setStockProducto(Integer stockProducto) {
            this.stockProducto = stockProducto;
        }


}
