package com.idat.idatapirest.dto;

public class ItemResponseDTO {
}
