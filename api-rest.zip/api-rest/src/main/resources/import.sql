insert into users(usuario,contrasenia,rol)values ('wilder','123','ROLE_ADMIN')
insert into users(usuario,contrasenia,rol)values ('profesor','123','ROLE_ADMIN')